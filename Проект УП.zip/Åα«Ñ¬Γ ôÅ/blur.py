import cv2
my_photo = cv2.imread('MyPhoto.jpg')
average_image = cv2.blur(my_photo,(7,7))
cv2.imshow('MyPhoto', average_image)
cv2.waitKey(0)
cv2.destroyAllWindows()