import cv2
img = cv2.imread('MyPhoto.jpg', cv2.IMREAD_GRAYSCALE)
cv2.imshow('MyPhoto', img)
cv2.waitKey(0)

cv2.destroyAllWindows()