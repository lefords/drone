import cv2
my_photo = cv2.imread('MyPhoto.jpg')
gaussian_image  = cv2.GaussianBlur(my_photo,(7,7),0)
cv2.imshow('MyPhoto', gaussian_image )
cv2.waitKey(0)
cv2.destroyAllWindows()