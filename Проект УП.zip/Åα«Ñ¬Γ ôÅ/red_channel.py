import cv2
my_photo = cv2.imread('dsc_0263.jpg')
red_channel = my_photo[:,:,2]
cv2.imshow('MyPhoto', red_channel)
cv2.waitKey(0)

cv2.destroyAllWindows()