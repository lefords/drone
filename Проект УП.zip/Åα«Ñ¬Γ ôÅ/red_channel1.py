import cv2
import numpy as np
my_photo = cv2.imread('dsc_0263.jpg')
red_channel = my_photo[:,:,2]
bin_img = np.zeros(my_photo.shape)
bin_img[red_channel > 200] = [0, 0, 255]
cv2.imshow('MyPhoto', bin_img)
cv2.waitKey(0)

cv2.destroyAllWindows()