import cv2
import numpy as np
my_photo = cv2.imread('White1.jpg')
h_channel = my_photo[:,:,0]
v_channel = my_photo[:,:,2]
bin_img = np.zeros(my_photo.shape)
bin_img[(h_channel < 70) * (h_channel > 20) * (v_channel>100)] = [0, 0, 255]
cv2.imshow('h_channel', h_channel)
cv2.imshow('v_channel', v_channel)
cv2.imshow('my_photo', my_photo)

kernel = np.ones((5,5),np.uint8)
opening = cv2.morphologyEx(bin_img, cv2.MORPH_OPEN, kernel)
closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel)

cv2.imshow('result', closing)
cv2.waitKey(0)

cv2.destroyAllWindows()