import cv2
import numpy as np
my_photo = cv2.imread('MyPhoto.jpg')
kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
im = cv2.filter2D(my_photo, -1, kernel)
cv2.imshow('MyPhoto', im )
cv2.waitKey(0)
cv2.destroyAllWindows()