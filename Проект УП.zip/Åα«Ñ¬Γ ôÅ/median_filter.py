import cv2
my_photo = cv2.imread('MyPhoto1.jpg')
median_image  = cv2.medianBlur(my_photo,5)
cv2.imshow('MyPhoto', median_image )
cv2.waitKey(0)
cv2.destroyAllWindows()